#1. Create a greeting for your program.
print("Hello dear")
#2. Ask the user for the city that they grew up in.
city=input("enter your city :\n")

#3. Ask the user for the name of a pet.
pet_name =input("enter your pet name :\n")


#4. Combine the name of their city and pet and show them their band name.
print("the name of your band is :", city + " " +pet_name)

#5. Make sure the input cursor shows on a new line, see the example at:
#   https://replit.com/@appbrewery/band-name-generator-end